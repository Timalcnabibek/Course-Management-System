package packages;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JPanel;

public class delete_tutors extends JFrame {
    
    private JTextField textField;
    private Database database; 
    private JFrame frame;
    public delete_tutors() {
    	getContentPane().setBackground(new Color(255, 255, 151));
        initialize();
        database = new Database();
    }
    
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    delete_tutors window = new delete_tutors();
                    window.setVisible(true); // Call setVisible() on the frame object
                    window.setLocationRelativeTo(null); // Center the frame on the screen

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        setTitle("Delete Course");
        setBounds(100, 100, 307, 382);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Delete Tutors");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 27));
        lblNewLabel.setBounds(55, 41, 171, 32);
        getContentPane().add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Enter Tutor ID");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
        lblNewLabel_1.setBounds(52, 129, 147, 25);
        getContentPane().add(lblNewLabel_1);

        textField = new JTextField();
        textField.setBounds(51, 165, 185, 25);
        getContentPane().add(textField);
        textField.setColumns(10);

        JButton btnNewButton = new JButton("Submit");
        btnNewButton.setBackground(new Color(255, 106, 106));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String courseIdToDelete = textField.getText();

                // Call the deleteCourse method passing the Database instance and the course ID to delete
                deletetutors(database, courseIdToDelete);
                dispose();
                refreshFrame();
            }
        });

        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnNewButton.setBounds(89, 241, 89, 23);
        getContentPane().add(btnNewButton);
        
        JPanel panel = new JPanel();
        panel.setBackground(new Color(255, 106, 106));
        panel.setBounds(20, 28, 241, 56);
        getContentPane().add(panel);
    }

    public void deletetutors(Database database, String courseIdToDelete) {
        // Get the database connection
        Connection connection = database.getConnection();

        try {
            // Prepare the SQL statement to delete the course
            String sql = "DELETE FROM teacher WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, courseIdToDelete);

            // Execute the SQL statement to delete the course
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(frame,"tutor deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(frame,"tutor could not be deleted!");
            }

            // Close the statement
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error deleting course: " + e.getMessage());
        }
    }
    public void refreshFrame() {
        // Dispose of the current JFrame
        dispose();
        
        // Create a new instance of the JFrame
        admin_tutors newFrame = new admin_tutors();
        newFrame.setVisible(true);
    }
}
