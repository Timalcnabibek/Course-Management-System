/**
 * 
 */
/**
 * 
 */
module final_assessment_of_java {
	requires java.desktop;
	requires java.sql;
}